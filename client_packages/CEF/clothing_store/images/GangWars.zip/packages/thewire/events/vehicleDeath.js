mp.events.add("vehicleDeath", (vehicle) => {
    vehicle.destroy();
});