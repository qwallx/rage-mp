mp.events.add("toggleCrouch", (player) => {
    player.data.isCrouched = !player.data.isCrouched;
});